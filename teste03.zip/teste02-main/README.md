# teste02



## Clone este projeto

```bash 
> git clone https://github.com/bruxinhok/teste02
```

##
Antes de executar o comando abaixo, certifique-se de estar no diretório do projeto que
você acabou de clonar!!

```bash
> cd teste02
> bash install.sh
```

### Uso
```bash
> npm start
```

### Info
```
prefix = !
```

## Recursos

|Criador de adesivos |                Característica       |
| :-----------: | :--------------------------------: |
|       ✅       |  Enviar foto com    Rubrica          |
|       ✅       | Responder uma foto                    |
|       ✅       | Responder a um vídeo ou GIF             |
|       ✅       | Enviar vídeo ou GIF com legenda      |
|       ✅       | Responder um adesivo ( adesivo para imagem ) |

| Other  |                     Feature                     |
| :------------: | :---------------------------------------------: |
|       ✅        |   Get a random meme             |
|       ✅        |   Text to speech                |
|       ✅        |   Writing feature 				|
|       ✅        |   What Anime Is This 			|
|       ✅        |   Url2Img ( Screeenshot Web )   |
|       ✅        |   Simsimi		                |

| Group  |                     Feature               |
| :-----------: | :--------------------------------: |
|       ✅        |   Tagall/Mentionall member       |
|       ✅        |   Tagall2/Mentionall member       |
|       ✅        |   Tagall3/Mentionall member       |
|       ✅        |   Kick Member Group	             |
|       ✅        |   Add Member Group	             |
|       ✅        |   Get List Admins Group          |
|       ✅        |   Get Group Invite Link          |
|       ✅        |   Bot leave the group            |

| Owner Bot  |                     Feature           |
| :-----------: | :--------------------------------: |
|       ✅        |   Definir prefixo                     |
|       ✅        |   Broadcast                      |
|       ✅        |  Limpar todos os chats             |





