const help = (prefix) => {
	return `𝐵𝑂𝑇 𝐶𝑅𝐼𝐴𝐷𝑂 𝑃𝑂𝑅 𝐵𝑌 𝐵𝑅𝑈𝑋𝐼𝑁𝐻𝑂 𝑀𝑂𝐷𝑆 𝑊𝐴𝑅
≪━─━─━─━─★─━─━─━─━≫

≪━─━─━─━──━─━─━─━≫≪━─━─━─━──━─━
𝑂𝑈𝑇𝑅𝑂𝑆 𝐶𝑂𝑀𝐴𝑁𝐷𝑂𝑆 𝑆𝐸𝑅𝐴𝑂 𝐴𝐷𝐼𝐶𝐼𝑂𝑁𝐴𝐷𝑂𝑆 𝐸𝑀 𝐵𝑅𝐸𝑉𝐸 𝐷𝐸𝑆𝐷𝐸 𝐽𝐴 𝐴𝐺𝑅𝐴𝐷𝐸Ç𝑂 𝑄𝑈𝐸𝑀 𝑃𝑂𝐷𝐸𝑅 𝐷𝐴𝑅 𝑈𝑀𝐴 𝐹𝑂𝑅Ç𝐴 𝐿𝐴 𝑁𝑂 𝑀𝐸𝑈 𝐶𝐴𝑁𝐴𝐿:https://youtu.be/hwJ31n05Qwk
━━━━━━━━❪❂❫━━━━━━━━

╭────卍 *MÚSICA*.
╰─❥〘1〙*${prefix}play*〘nome da musica〙
╭─❥〘2〗*${prefix}ytmp3 (LINK)*
╰─❥〘3〙*${prefix}ytmp4 (LINK)*

╭────卍 *RECURSOS MAKER*
╰─❥〘4〙*${prefix}sticker*
╭─❥〘5〙*${prefix}stickernobg*
╰─❥〘6〙*${prefix}toimg*
╭─❥〘7〙*${prefix}tsticker*
╰─❥
╭────卍 *OUTROS COMANDOS*
╰─❥〘8〙*${prefix}gato*
╭─❥〘9〙*${prefix}meme*
╰─❥〘10〙*${prefix}memeindo*
╭─❥〘11〙*${prefix}gtts*
╰─❥〘12〙*${prefix}loli*
╭─❥〘13〙*${prefix}simi*
╰─❥〘14〙*${prefix}ocr*
╭─❥〘15〙*${prefix}nsfwloli*
╰─❥〘16〙*${prefix}url2img*
╭─❥〘17〙*${prefix}wait*
╰─❥〘18〙*${prefix}setprefix*
╭─❥〘18〙*${prefix}imagem*
╰─❥〘29〙*${prefix}wame*

╭────卍 *GRUPO*
╰─❥〘20〙*${prefix}add* 55𝑋𝑋𝑋𝑋𝑋
╭─❥〘21〙*${prefix}remover* 
╰─❥〘22〙*${prefix}promote*
╭─❥〘23〙*${prefix}demote*
╰─❥〘24〙*${prefix}fechar*
╭─❥〘25〙*${prefix}abrir*
╰─❥〘26〙*${prefix}linkgroup*
╭─❥〘27〙*${prefix}leave*
╰─❥〘28〙*${prefix}tagall*
╭─❥〘29〙*${prefix}simih*
╰─❥〘30〙*${prefix}leave*
╭─❥〘31〙*${prefix}gay<marque o cara*
╰─❥〘32〙*${prefix}artinome*
╭─❥〘33〙*${prefix}listadmins*
╰─❥〘34〙*${prefix}tagall2*
╭─❥〘35〙*${prefix}welcome*
╰─❥〘36〙*${prefix}tagall3*
╰────卍 *𝐵𝑅𝑈𝑋𝐼𝑁𝐻𝑂 𝑀𝑂𝐷𝑆 𝑊𝐴𝑅*`
}

exports.help = help
